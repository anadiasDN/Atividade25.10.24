const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');


app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true })); 
app.use(express.json()); 


app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/index.html'));
});


app.get('/produtos.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/produtos.html'));
});


app.get('/sobre.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/sobre.html'));
});


app.post('/contato', (req, res) => {
    try {
        const { nome, email, mensagem } = req.body;
        
        
        console.log('Dados recebidos:', { nome, email, mensagem });

        
        res.send(`
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Mensagem Recebida</title>
                <link rel="stylesheet" href="/css/style.css">
            </head>
            <body>
                <nav>
                    <div class="container">
                        <h1>Café Artesanal</h1>
                        <ul>
                            <li><a href="/index.html">Home</a></li>
                            <li><a href="/produtos.html">Produtos</a></li>
                            <li><a href="/sobre.html">Sobre</a></li>
                        </ul>
                    </div>
                </nav>
                <main class="container">
                    <div class="mensagem-container">
                        <h2>Mensagem Recebida!</h2>
                        <div class="dados-mensagem">
                            <p><strong>Nome:</strong> ${nome}</p>
                            <p><strong>Email:</strong> ${email}</p>
                            <p><strong>Mensagem:</strong> ${mensagem}</p>
                        </div>
                        <a href="/index.html" class="btn">Voltar para a página inicial</a>
                    </div>
                </main>
            </body>
            </html>
        `);
    } catch (error) {
        console.error('Erro ao processar formulário:', error);
        res.status(500).send('Erro ao processar o formulário');
    }
});


const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
function validarFormulario() {
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const mensagem = document.getElementById('mensagem').value;

    if (nome.trim() === '') {
        alert('Por favor, preencha o campo nome.');
        return false;
    }

    if (email.trim() === '') {
        alert('Por favor, preencha o campo email.');
        return false;
    }

    if (!validarEmail(email)) {
        alert('Por favor, insira um email válido.');
        return false;
    }

    if (mensagem.trim() === '') {
        alert('Por favor, preencha o campo mensagem.');
        return false;
    }

    return true;
}

function validarEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}


document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('formContato');
    if (form) {
        form.addEventListener('submit', function(e) {
            if (!validarFormulario()) {
                e.preventDefault();
            }
        });
    }
});